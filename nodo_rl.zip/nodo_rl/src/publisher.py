import rospy
import numpy as np
from nodo_vision.msg import Coord
from nodo_rl.msg import Action

class Nodo_RL:

    def __init__(self) -> None:
        rospy.init_node("nodo_publisher",anonymous=True)
        self.mi_primer_publicador = rospy.Publisher("topic2", Action,queue_size=5)
        self.tiempo_ciclo = rospy.Rate(10)

    def enviar(self, acciones) -> None:
        self.mi_primer_publicador.publish(acciones)
        self.tiempo_ciclo.sleep()
    
    def start(self) -> None:
        while not rospy.is_shutdown():
            self.rutina() 

    def recibir_mensajes(self, data: Coord) -> None:
        
        obstacles = set()
        for numero in data.coordenadas:
            coods = [n for n in str(np.uint8(numero))]
            obstacles.add((coods[0], coods[1]))

        print(obstacles)
        actions = Action()
        solution = [1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2]
        actions.acciones = solution
        
        
        # maze_env = MazeEnv(render=False, obstacles=obstacles)
        # ppo_model = PPO.load("ppo_maze_prueba7.model")

        self.enviar(actions)
        print('Enviado')


if __name__ == '__main__':
    nodo = Nodo_RL()
    rospy.Subscriber("topic1", Coord, nodo.recibir_mensajes)

    rospy.spin()

    nodo.start()