import rospy
import numpy as np
import time
from MazeEnv import MazeEnv
from stable_baselines3 import PPO
from nodo_vision.msg import Coord
from nodo_rl.msg import Action


def optimizar_ruta(lista):
    lista_simplificada = lista

    for idx, element in enumerate(lista):

        if lista.count(element) > 1:
            pos = lista[idx + 1:].index(element) + len(lista[:idx + 1])
            lista_simplificada = lista[:idx] + lista[pos:]
            break

    return lista_simplificada


def obtener_acciones(lista):

    acciones = list()
    prev_state = (-10, -10)

    for state in lista:

        if state[0] - prev_state[0] == 1:
            acciones.append(2)
        elif state[0] - prev_state[0] == -1:
            acciones.append(3)
        elif state[1] - prev_state[1] == 1:
            acciones.append(1)
        elif state[1] - prev_state[1] == -1:
            acciones.append(0)
        prev_state = state

    return acciones


class Nodo_RL:

    def __init__(self) -> None:
        rospy.init_node("nodo_publisher",anonymous=True)
        self.mi_primer_publicador = rospy.Publisher("topic2", Action,queue_size=5)
        self.tiempo_ciclo = rospy.Rate(10)

    def enviar(self, acciones) -> None:
        self.mi_primer_publicador.publish(acciones)
        self.tiempo_ciclo.sleep()
    
    def start(self) -> None:
        while not rospy.is_shutdown():
            self.rutina() 

    def recibir_mensajes(self, data: Coord) -> None:
        
        ###### Obtener posición de los obstáculos ######

        obstacles = set()
        for numero in data.coordenadas:
            coods = [int(n) for n in str(np.uint8(numero)-1)]
            obstacles.add((coods[0], coods[1]))

        print(f"Obstáculos recibidos: {obstacles}")


        ######### Calcular acciones a realizar #########

        maze_env = MazeEnv(render=True, obstacles=obstacles)
        model = PPO.load('src/nodo_rl/src/ppo_maze_prueba7.model')
        
        done = False
        actions = []
        states = [(0, 7)]
        obs, _ = maze_env.reset()

        while not done:

            action, _ = model.predict(obs)
            actions.append(int(action))
            obs, reward, done, truncated, info = maze_env.step(action)
            states.append(tuple(info["current_state"]))
            if truncated:
                done = False
                actions = []
                states = [(0, 7)]
                obs, _ = maze_env.reset()

        print(f"Solución obtenida: {actions}")

        maze_env = MazeEnv(render=True, obstacles=obstacles)
        for action in actions:
            maze_env.step(action)

        ######### Optimizar solucion obtenida ##########

        for i, elem in enumerate(reversed(states[1:])):
            if elem == states[0]:
                states = states[len(states) - i - 1:]

        while len(states) != len(set(states)):
            states = optimizar_ruta(states)

        actions = obtener_acciones(states)
        print(f"Solución optimizada: {actions}")

        maze_env = MazeEnv(render=True, obstacles=obstacles)
        for action in actions:
            maze_env.step(action)

        ############ Enviar solución óptima ############
        
        solution = Action()
        solution.acciones = actions
        
        self.enviar(solution)
        print('Enviado')


if __name__ == '__main__':

    nodo = Nodo_RL()

    rospy.Subscriber("topic1", Coord, nodo.recibir_mensajes)
    rospy.spin()

    nodo.start()