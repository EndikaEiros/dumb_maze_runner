import rospy
import numpy as np
import time
from MazeEnv import MazeEnv
from stable_baselines3 import PPO
from nodo_vision.msg import Coord
from nodo_rl.msg import Action

class Nodo_RL:

    def __init__(self) -> None:
        rospy.init_node("nodo_publisher",anonymous=True)
        self.mi_primer_publicador = rospy.Publisher("topic2", Action,queue_size=5)
        self.tiempo_ciclo = rospy.Rate(10)

    def enviar(self, acciones) -> None:
        self.mi_primer_publicador.publish(acciones)
        self.tiempo_ciclo.sleep()
    
    def start(self) -> None:
        while not rospy.is_shutdown():
            self.rutina() 

    def recibir_mensajes(self, data: Coord) -> None:
        
        #### Obtener posición de los obstáculos ####
        obstacles = set()
        for numero in data.coordenadas:
            coods = [int(n) for n in str(np.uint8(numero)-1)]
            obstacles.add((coods[0], coods[1]))

        print(f"Obstáculos: {obstacles}")

        #### Calcular acciones ####
        maze_env = MazeEnv(render=True, obstacles=obstacles)
        model = PPO.load('src/nodo_rl/src/ppo_maze_prueba7.model')
        
        done = False
        solution = []
        obs, _ = maze_env.reset()

        while not done:

            action, _ = model.predict(obs)
            solution.append(int(action))
            obs, reward, done, truncated, info = maze_env.step(action)

            if truncated:
                done = False
                solution = []
                obs, _ = maze_env.reset()

        print(f"Solución: {solution}")

        #### Enviar solición ####
        
        actions = Action()
        actions.acciones = solution
        
        self.enviar(actions)
        print('Enviado')


if __name__ == '__main__':
    nodo = Nodo_RL()
    rospy.Subscriber("topic1", Coord, nodo.recibir_mensajes)
    # actions = Action()
    # solution = [0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2]
    # solution = [ np.uint8(i)  for i in solution]
    # actions.acciones = solution
    
    
    # maze_env = MazeEnv(render=False, obstacles=obstacles)
    # ppo_model = PPO.load("ppo_maze_prueba7.model")


    rospy.spin()

    nodo.start()