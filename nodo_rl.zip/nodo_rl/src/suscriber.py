import rospy
import numpy as np
from nodo_vision.msg import Coord
from stable_baselines3 import PPO
from MazeEnv import MazeEnv

rospy.init_node("nodo_RL",anonymous=True)

def recibir_mensajes(data: Coord) -> None:
    
    obstacles = set()
    for numero in data.coordenadas:
        coods = [n for n in str(np.uint8(numero))]
        obstacles.add((coods[0], coods[1]))

    print(obstacles)

    solution = [1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2]

    

    # maze_env = MazeEnv(render=False, obstacles=obstacles)
    # ppo_model = PPO.load("ppo_maze_prueba7.model")


rospy.Subscriber("topic1", Coord, recibir_mensajes)

rospy.spin()

# mensaje = Coord()
# lista = set()
# for i in range(5):
#     lista.add(np.uint8(i))

# mensaje.coordenadas = lista